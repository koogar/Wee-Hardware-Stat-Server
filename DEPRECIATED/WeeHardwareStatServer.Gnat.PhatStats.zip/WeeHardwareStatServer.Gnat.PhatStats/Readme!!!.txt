Wee Hardware Stat Server (Gnat-Stats & Phat-Stats Compatiable)
Copyright (C) 2021  Vinod Mishra
----------------------------------------------------------------

Edit the appsettings.json 

  "SerialPortSettings": {
    "Port": "COM3",  //Change to your Specific Arduino port

Run the WeeHardwareStatServer.exe as Admin