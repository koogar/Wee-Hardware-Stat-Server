Windows Service Installation (Silent auto run on windows startup)

Place the contents of this folder in the root

This is a simple console application and has built in support to be run as a Windows Service as well which would be the easiest way to get it working.
Please make sure you have the latest .net 6 runtime installed https://dotnet.microsoft.com/download/dotnet/6.0
Please change settings to fit your use case in appsetttings.json
Run 'InstallService.bat' as an administrator.

Uninstallation
Run "DeleteService.bat" as an administrator.

https://gitlab.com/vinodmishra/wee-hardware-stat-server

